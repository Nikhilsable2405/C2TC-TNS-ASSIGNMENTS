
abstract class CurrentAcc extends BankAcc {
    private float creditLimit;

    public CurrentAcc(int accNo, String accNm, float accBal, float creditLimit) {
        super(accNo, accNm, accBal);
        this.creditLimit = creditLimit;
    }

    @Override
    public void withdraw(float amount) {
        if (getAccBal() + creditLimit - amount >= 0) {
            deposite(-amount);
        } else {
            System.out.println("Insufficient balance and credit limit.");
        }
    }

    @Override
    public String toString() {
        return "CurrentAcc{" +
                "creditLimit=" + creditLimit +
                ", " + super.toString() +
                '}';
    }
}
