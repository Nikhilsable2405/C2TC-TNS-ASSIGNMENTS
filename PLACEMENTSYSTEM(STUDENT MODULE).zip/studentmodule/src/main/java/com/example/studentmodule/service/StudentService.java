package com.example.studentmodule.service;

import com.example.studentmodule.entity.Student;
import com.example.studentmodule.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    public Optional<Student> getStudentById(Long id) {
        return studentRepository.findById(id);
    }

    public Student createStudent(Student student) {
        return studentRepository.save(student);
    }

    public Student updateStudent(Long id, Student studentDetails) {
        Optional<Student> student = studentRepository.findById(id);
        if (student.isPresent()) {
            Student existingStudent = student.get();
            existingStudent.setRollNo(studentDetails.getRollNo());
            existingStudent.setName(studentDetails.getName());
            existingStudent.setQualification(studentDetails.getQualification());
            existingStudent.setYear(studentDetails.getYear());
            existingStudent.setHallTicketNo(studentDetails.getHallTicketNo());
            return studentRepository.save(existingStudent);
        }
        return null;
    }

    public void deleteStudent(Long id) {
        studentRepository.deleteById(id);
    }
}