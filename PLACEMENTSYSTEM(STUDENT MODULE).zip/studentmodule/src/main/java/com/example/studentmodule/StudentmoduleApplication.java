package com.example.studentmodule;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentmoduleApplication {

    public static void main(String[] args) {
        SpringApplication.run(StudentmoduleApplication.class, args);
    }
}