public class Main {
    public static void main(String[] args) {
        BankFactory bankFactory = new MMBankFactory();

        SavingAcc savingAcc = bankFactory.getNewSavingAcc(101, "Nikhil Sable", 5000, true);
        CurrentAcc currentAcc = bankFactory.getNewCurrentAcc(102, "Shubham Jadhav", 7000, 2000);

        savingAcc.withdraw(4500);
        currentAcc.withdraw(8500);

        System.out.println(savingAcc);
        System.out.println(currentAcc);
    }
}
